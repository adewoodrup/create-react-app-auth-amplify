import React from 'react';
import { render } from 'react-dom';
import Carousel from './Carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';

function App() {
  return(
    <div style={
      {
        backgroundColor: '#474140',
      }
        }>
        <Carousel />
    </div>
  );
}
export default App
//render(<App />, document.getElementById('root'));

