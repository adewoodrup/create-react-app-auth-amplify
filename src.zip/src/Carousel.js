import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import Slide1 from './images/Slide1.PNG';
import Slide2 from './images/Slide2.PNG';
import Slide3 from './images/Slide3.PNG';
import Slide4 from './images/Slide4.PNG';
import Slide5 from './images/Slide5.PNG';
import Slide6 from './images/Slide6.PNG';
import Slide7 from './images/Slide7.PNG';
import Slide8 from './images/Slide8.PNG';
import Slide9 from './images/Slide9.PNG';
import Slide10 from './images/Slide10.PNG';
import Slide11 from './images/Slide11.PNG';
import Slide12 from './images/Slide12.PNG';
import Slide13 from './images/Slide13.PNG';
import Slide14 from './images/Slide14.PNG';
import Slide15 from './images/Slide15.PNG';
import Slide16 from './images/Slide16.PNG';
import Slide17 from './images/Slide17.PNG';


//const firstSlide = require ('/Slide1.PNG')

export default () => (
    <Carousel >
        <div>
            <img alt="" src={Slide1} />
            <p className="legend">Opening Slide</p>
        </div>
        <div>
            <img alt="" src={Slide2} />
            <p className="legend">Our Values, Vission and Mission</p>
        </div>
        <div>
            <img alt="" src={Slide3} />
            <p className="legend">Total Market Opportunity</p>
        </div>
        <div>
            <img alt="" src={Slide4} />
            <p className="legend">Intercom Market Opportunity</p>
        </div>
        <div>
            <img alt="" src={Slide5} />
            <p className="legend">Policing Market Opportunity</p>
        </div>
        <div>
            <img alt="" src={Slide6} />
            <p className="legend">Prison Market Opportunity</p>
        </div>
        <div>
            <img alt="" src={Slide7} />
            <p className="legend">Healthcare Market Opportunity</p>
        </div>
        <div>
            <img alt="" src={Slide8} />
            <p className="legend">Digityze have three Products hosted on one Platform</p>
        </div>
        <div>
            <img alt="" src={Slide9} />
            <p className="legend">Digityze PASS</p>
        </div>
        <div>
            <img alt="" src={Slide10} />
            <p className="legend">Digityze CONCIERGE</p>
        </div>
        <div>
            <img alt="" src={Slide11} />
            <p className="legend">Digityze Lingo</p>
        </div>
        <div>
            <img alt="" src={Slide12} />
            <p className="legend">Inflight Proof of Concepts</p>
        </div>
        <div>
            <img alt="" src={Slide13} />
            <p className="legend">UK Projections</p>
        </div>
        <div>
            <img alt="" src={Slide14} />
            <p className="legend">Product Growth</p>
        </div>
        <div>
            <img alt="" src={Slide15} />
            <p className="legend">People Growth</p>
        </div>
        <div>
            <img alt="" src={Slide16} />
            <p className="legend">Financial Projections</p>
        </div>
        <div>
            <img alt="" src={Slide17} />
            <p className="legend">Thank you for reading</p>
        </div>
    </Carousel>
);
